
/*  Arquivo de exemplo de programa principal
* 
*/
package Pacote;

public class Principal {
                public static void main(String args[]){ 
                	new Alunos();
                	
                }    
}
